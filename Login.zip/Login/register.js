document.getElementById("registerForm").addEventListener("submit", function (event) {
    event.preventDefault();
    alert("Your account has been successfully registered!");
  });