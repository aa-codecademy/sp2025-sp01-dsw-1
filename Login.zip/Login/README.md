# sp2025-sp01-dsw-1


Description of the feature:
Drop Shipping is becoming very popular and it's a great way to start a small business without owning a product line, a brand, or a manufacturing facility. The internet made this concept very easy and affordable. All you need is a webshop, a third-party supplier, and a delivery method. There are a lot of suppliers online as well, so you can easily order stock, ship orders, and put new products for sale with a few clicks and taps on your keyboard. The shop we are looking for needs to have all the basic functionality of a webshop, including having an order system, listing products, a cart, and a form for the user to fill in their information so they could get their order. The orders should initially arrive at our email address (phase 2). A payment system is not necessary, since the people will be paying when they get the delivery.

Requrements:
Navigation
-Home
-Categories
-Contact
-Go to Cart
-Go to login/register form

Home
-Shows categories for products
-Each category can be clicked and leads to a category page
-Products with most sales shown on homepage

Category Page
-Lists all products from that category
-Possibility to sort and filter the products

Contact Page
-A form where users send messages to the company

Cart page
-Lists all products in the cart
-Lists the prices and a sum of them
-Has a button to make an order
   -Make an order page
     *Form that requires name, street, phone number, email, and preferred day of delivery ( Monday to Saturday )


Data
-All products should be read from a static JSON file
-All cart functionality should work with local storage

all the color and button styles are up to your creativity !!!